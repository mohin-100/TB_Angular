export const keys = {
  mock_api: "669f5ca1b132e2c136fd8dc6",
};